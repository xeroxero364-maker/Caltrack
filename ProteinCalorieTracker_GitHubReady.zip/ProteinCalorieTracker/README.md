# Protein + Calories Tracker v2

Android 15-friendly personal tracker focused only on protein and calories.

### v2 features
- Daily calorie + protein totals
- Daily calorie/protein goals
- Progress bars
- Food log with delete
- Built-in common foods
- Custom food creation
- Last 7 days of history
- Offline local storage
- No account, ads, or internet permission

Open the project in Android Studio and use:
Build > Build APK(s) > Build APK(s)

APK output:
app/build/outputs/apk/debug/app-debug.apk
