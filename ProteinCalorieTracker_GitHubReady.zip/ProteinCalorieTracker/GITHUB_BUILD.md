# Build the APK from your phone

1. Create a GitHub account if you don't have one.
2. Create a new repository.
3. Upload **all the files inside this project**, not just the ZIP itself.
4. Commit them to the `main` branch.
5. Open the repository's **Actions** tab.
6. Select **Build Android APK**.
7. Tap **Run workflow**.
8. Wait for the green checkmark.
9. Open the completed workflow run.
10. Under **Artifacts**, download `ProteinCalorieTracker-debug`.
11. Extract it and install `app-debug.apk` on your Android phone.

If Android asks, allow your browser/file manager to install unknown apps.
