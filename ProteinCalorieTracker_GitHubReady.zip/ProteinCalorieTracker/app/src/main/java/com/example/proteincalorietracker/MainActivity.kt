package com.example.proteincalorietracker

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

data class Food(val name: String, val calories: Int, val protein: Double, val isCustom: Boolean = false)
data class Entry(val id: Long, val food: Food, val amount: Double)

private val builtIns = listOf(
    Food("Egg", 72, 6.3),
    Food("Milk (100 ml)", 61, 3.2),
    Food("Paneer (100 g)", 265, 18.3),
    Food("Greek yogurt (100 g)", 59, 10.0),
    Food("Curd / yogurt (100 g)", 61, 3.5),
    Food("Banana", 105, 1.3),
    Food("Oats (100 g)", 389, 16.9),
    Food("Peanut butter (100 g)", 588, 25.0),
    Food("Almonds (100 g)", 579, 21.2),
    Food("Walnuts (100 g)", 654, 15.2),
    Food("Makhana (100 g)", 347, 9.7),
    Food("Whey protein (1 scoop)", 120, 25.0)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App(this) }
    }
}

@Composable
fun App(context: Context) {
    val prefs = remember { context.getSharedPreferences("tracker", Context.MODE_PRIVATE) }
    val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    var entries by remember(today) { mutableStateOf(loadEntries(prefs, today)) }
    var customFoods by remember { mutableStateOf(loadCustomFoods(prefs)) }
    var calorieGoal by remember { mutableIntStateOf(prefs.getInt("calorieGoal", 2200)) }
    var proteinGoal by remember { mutableIntStateOf(prefs.getInt("proteinGoal", 130)) }

    var screen by remember { mutableIntStateOf(0) }
    var showAdd by remember { mutableStateOf(false) }
    var showCustom by remember { mutableStateOf(false) }
    var showGoals by remember { mutableStateOf(false) }

    val foods = builtIns + customFoods
    val calories = entries.sumOf { (it.food.calories * it.amount).roundToInt() }
    val protein = entries.sumOf { it.food.protein * it.amount }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFFB6F36A),
            onPrimary = Color(0xFF15200D),
            background = Color(0xFF0D0F0C),
            surface = Color(0xFF171A15)
        )
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("Protein + Calories", fontWeight = FontWeight.Bold)
                            Text("Today • $today", fontSize = 12.sp, color = Color.LightGray)
                        }
                    },
                    actions = {
                        IconButton(onClick = { showGoals = true }) {
                            Icon(Icons.Default.Settings, contentDescription = "Goals")
                        }
                    }
                )
            },
            floatingActionButton = {
                FloatingActionButton(onClick = { showAdd = true }) {
                    Icon(Icons.Default.Add, contentDescription = "Add food")
                }
            },
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(screen == 0, { screen = 0 }, icon = {}, label = { Text("Today") })
                    NavigationBarItem(screen == 1, { screen = 1 }, icon = {}, label = { Text("History") })
                }
            }
        ) { padding ->
            if (screen == 0) {
                Today(
                    padding, calories, protein, calorieGoal, proteinGoal, entries,
                    onDelete = { entry ->
                        entries = entries.filterNot { it.id == entry.id }
                        saveEntries(prefs, today, entries)
                    },
                    onAddCustom = { showCustom = true }
                )
            } else {
                History(padding, prefs)
            }

            if (showAdd) {
                AddFoodDialog(
                    foods = foods,
                    onDismiss = { showAdd = false },
                    onAdd = { food, amount ->
                        entries = entries + Entry(System.nanoTime(), food, amount)
                        saveEntries(prefs, today, entries)
                        showAdd = false
                    }
                )
            }

            if (showCustom) {
                CustomFoodDialog(
                    onDismiss = { showCustom = false },
                    onCreate = { food ->
                        customFoods = customFoods + food
                        saveCustomFoods(prefs, customFoods)
                        showCustom = false
                    }
                )
            }

            if (showGoals) {
                GoalsDialog(
                    calorieGoal, proteinGoal,
                    onDismiss = { showGoals = false },
                    onSave = { c, p ->
                        calorieGoal = c
                        proteinGoal = p
                        prefs.edit().putInt("calorieGoal", c).putInt("proteinGoal", p).apply()
                        showGoals = false
                    }
                )
            }
        }
    }
}

@Composable
fun Today(
    padding: PaddingValues, calories: Int, protein: Double, calorieGoal: Int,
    proteinGoal: Int, entries: List<Entry>, onDelete: (Entry) -> Unit,
    onAddCustom: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)
            .padding(padding).padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard("Calories", "$calories / $calorieGoal kcal", Modifier.weight(1f))
                StatCard("Protein", "${"%.1f".format(protein)} / $proteinGoal g", Modifier.weight(1f))
            }
        }
        item {
            ProgressCard("Calories", calories.toFloat() / calorieGoal.coerceAtLeast(1), "$calories / $calorieGoal kcal")
        }
        item {
            ProgressCard("Protein", protein.toFloat() / proteinGoal.coerceAtLeast(1), "${"%.1f".format(protein)} / $proteinGoal g")
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("Food log", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                TextButton(onClick = onAddCustom) { Text("Create food") }
            }
        }
        if (entries.isEmpty()) {
            item {
                Card(shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.fillMaxWidth().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Nothing logged yet", fontWeight = FontWeight.Bold)
                        Text("Tap + to add your first food.", color = Color.LightGray)
                    }
                }
            }
        } else {
            items(entries, key = { it.id }) { entry ->
                Card(shape = RoundedCornerShape(18.dp)) {
                    Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(entry.food.name, fontWeight = FontWeight.SemiBold)
                            Text("× ${entry.amount}", color = Color.Gray, fontSize = 12.sp)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("${(entry.food.calories * entry.amount).roundToInt()} kcal")
                            Text("${"%.1f".format(entry.food.protein * entry.amount)} g protein",
                                color = MaterialTheme.colorScheme.primary)
                        }
                        IconButton(onClick = { onDelete(entry) }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete")
                        }
                    }
                }
            }
        }
        item { Spacer(Modifier.height(85.dp)) }
    }
}

@Composable
fun ProgressCard(title: String, raw: Float, label: String) {
    Card(shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(16.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(title, fontWeight = FontWeight.SemiBold)
                Text(label, color = Color.LightGray, fontSize = 12.sp)
            }
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(
                progress = { raw.coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth().height(9.dp),
                trackColor = Color(0xFF30352C)
            )
        }
    }
}

@Composable
fun StatCard(title: String, value: String, modifier: Modifier) {
    Card(modifier, shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(18.dp)) {
            Text(title, color = Color.LightGray, fontSize = 13.sp)
            Text(value, fontSize = 21.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun AddFoodDialog(foods: List<Food>, onDismiss: () -> Unit, onAdd: (Food, Double) -> Unit) {
    var selected by remember { mutableStateOf(foods.first()) }
    var amount by remember { mutableStateOf("1") }
    var expanded by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add food") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Box {
                    OutlinedButton(onClick = { expanded = true }) { Text(selected.name) }
                    DropdownMenu(expanded, { expanded = false }) {
                        foods.forEach { f ->
                            DropdownMenuItem(Text(f.name), {
                                selected = f
                                expanded = false
                            })
                        }
                    }
                }
                OutlinedTextField(amount, { amount = it }, label = { Text("Servings / units") }, singleLine = true)
                Text("Per unit: ${selected.calories} kcal • ${selected.protein} g protein", color = Color.Gray, fontSize = 12.sp)
            }
        },
        confirmButton = {
            TextButton(onClick = { amount.toDoubleOrNull()?.takeIf { it > 0 }?.let { onAdd(selected, it) } }) { Text("Add") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun CustomFoodDialog(onDismiss: () -> Unit, onCreate: (Food) -> Unit) {
    var name by remember { mutableStateOf("") }
    var kcal by remember { mutableStateOf("") }
    var protein by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Create custom food") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Food name") }, singleLine = true)
                OutlinedTextField(kcal, { kcal = it }, label = { Text("Calories per unit") }, singleLine = true)
                OutlinedTextField(protein, { protein = it }, label = { Text("Protein per unit (g)") }, singleLine = true)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val c = kcal.toIntOrNull()
                val p = protein.toDoubleOrNull()
                if (name.isNotBlank() && c != null && p != null) onCreate(Food(name.trim(), c, p, true))
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun GoalsDialog(cGoal: Int, pGoal: Int, onDismiss: () -> Unit, onSave: (Int, Int) -> Unit) {
    var c by remember { mutableStateOf(cGoal.toString()) }
    var p by remember { mutableStateOf(pGoal.toString()) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Daily goals") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                OutlinedTextField(c, { c = it }, label = { Text("Calories (kcal)") }, singleLine = true)
                OutlinedTextField(p, { p = it }, label = { Text("Protein (g)") }, singleLine = true)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val cc = c.toIntOrNull()
                val pp = p.toIntOrNull()
                if (cc != null && cc > 0 && pp != null && pp > 0) onSave(cc, pp)
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun History(padding: PaddingValues, prefs: android.content.SharedPreferences) {
    val days = (0..6).map {
        val d = java.util.Calendar.getInstance().apply { add(java.util.Calendar.DAY_OF_YEAR, -it) }.time
        SimpleDateFormat("yyyy-MM-dd", Locale.US).format(d)
    }
    LazyColumn(
        Modifier.fillMaxSize().padding(padding).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item { Text("Last 7 days", fontSize = 22.sp, fontWeight = FontWeight.Bold) }
        items(days) { day ->
            val es = loadEntries(prefs, day)
            val kcal = es.sumOf { (it.food.calories * it.amount).roundToInt() }
            val protein = es.sumOf { it.food.protein * it.amount }
            Card(shape = RoundedCornerShape(16.dp)) {
                Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(day, fontWeight = FontWeight.SemiBold)
                    Column(horizontalAlignment = Alignment.End) {
                        Text("$kcal kcal")
                        Text("${"%.1f".format(protein)} g protein", color = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }
    }
}

fun loadEntries(prefs: android.content.SharedPreferences, day: String): List<Entry> {
    val arr = try { JSONArray(prefs.getString("day_$day", "[]")) } catch (_: Exception) { JSONArray() }
    val result = mutableListOf<Entry>()
    for (i in 0 until arr.length()) {
        val o = arr.getJSONObject(i)
        result += Entry(
            o.getLong("id"),
            Food(o.getString("name"), o.getInt("cal"), o.getDouble("protein"), o.optBoolean("custom", false)),
            o.getDouble("amount")
        )
    }
    return result
}

fun saveEntries(prefs: android.content.SharedPreferences, day: String, entries: List<Entry>) {
    val arr = JSONArray()
    entries.forEach {
        arr.put(JSONObject().apply {
            put("id", it.id); put("name", it.food.name); put("cal", it.food.calories)
            put("protein", it.food.protein); put("custom", it.food.isCustom); put("amount", it.amount)
        })
    }
    prefs.edit().putString("day_$day", arr.toString()).apply()
}

fun loadCustomFoods(prefs: android.content.SharedPreferences): List<Food> {
    val arr = try { JSONArray(prefs.getString("customFoods", "[]")) } catch (_: Exception) { JSONArray() }
    return (0 until arr.length()).map {
        val o = arr.getJSONObject(it)
        Food(o.getString("name"), o.getInt("cal"), o.getDouble("protein"), true)
    }
}

fun saveCustomFoods(prefs: android.content.SharedPreferences, foods: List<Food>) {
    val arr = JSONArray()
    foods.forEach { arr.put(JSONObject().apply {
        put("name", it.name); put("cal", it.calories); put("protein", it.protein)
    }) }
    prefs.edit().putString("customFoods", arr.toString()).apply()
}
